﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project.Models.ShoppingCart
{
    public class OrderSummary
    {
    }
}