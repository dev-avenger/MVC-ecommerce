﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EntityLib.EntityClass
{
    public class EasyPaisaDetail
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
        public string NICNumber { get; set; }
        public string MobileNumber { get; set; }
        public string AccountName { get; set; }



    }
}