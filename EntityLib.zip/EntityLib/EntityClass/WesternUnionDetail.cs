﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EntityLib.EntityClass
{
    public class WesternUnionDetail
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string NICNumber { get; set; }
        public string MobileNumber { get; set; }
        public string AccountName { get; set; }
        public string Country { get; set; }


    }
}