﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EntityLib.BusinessLayer;

namespace EntityLib.EntityClass
{
    public class Slider
    {
        public int Id { get; set; }
        public string SlideName { get; set; }
        public string SlideImage { get; set; }
    }
}