﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EntityLib.EntityClass
{
    public class SocialMediaLink
    {
        public int id { get; set; }
        public string facebook { get; set; }
        public string twitter { get; set; }
        public string instagram { get; set; }
        public string googleplus { get; set; }
        public string youtube { get; set; }

    }
}